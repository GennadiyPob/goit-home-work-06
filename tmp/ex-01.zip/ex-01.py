# Enter values in programm:
name = 'Gennadiy'
age = 47